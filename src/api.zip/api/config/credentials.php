<?php 
/**
 * This file contains the credentials for the application.
 */
/* Database Credentials */
define('DB_HOST', 'localhost');
define('DB_USERNAME', [
    /* Localhost */
    __LOCALHOST__ => 'root', 

    /* partsv2.abs.company */ 
    __PARTS_V2__ => 'u356746783_parts_v2',

    /* washv2.abs.company */
    __WASH_V2__ => 'u356746783_washv2_abs',

    /* tenleasing.absyeg.store */
    __TEN_LEASING__ => 'u356746783_tenleasing',

    /* vanguard.absyeg.store */
    __VANGUARD__ => 'u356746783_vanguard',
    ][$offset]
);

define('DB_PASSWORD', [
    /* Localhost */
    __LOCALHOST__ => '',

    /* partsv2.abs.company */ 
    __PARTS_V2__ => 'Fr:W="|ryHn/AQ.%2.pznd`N*#([97/Q',

    /* washv2.abs.company */
    __WASH_V2__ => 'R~%CWR3+p],N_sSN_@D"YPKSo-}"ay,=',

    /* tenleasing.absyeg.store */
    __TEN_LEASING__ => '[hP>dQ/?4zXp:w"^P*^J9g;``EC&`o3V',

    /* vanguard.absyeg.store */
    __VANGUARD__ => '9j9Sr`q"!z{9tN<2{~q\"XJ!,h=?)4M]',
    ][$offset]
);

define('DB_NAME', [
    /* Localhost */ 
    __LOCALHOST__ => 'abs', 

    /* partsv2.abs.company */ 
    __PARTS_V2__ => 'u356746783_parts_v2',

    /* washv2.abs.company */
    __WASH_V2__ => 'u356746783_washv2_abs',

    /* tenleasing.absyeg.store */
    __TEN_LEASING__ => 'u356746783_tenleasing',

    /* vanguard.absyeg.store */
    __VANGUARD__ => 'u356746783_vanguard',
    ][$offset]
);
?>