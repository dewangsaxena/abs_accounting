<?php 
/**
 * This file contains the credentials for the application.
 */
/* Database Credentials */
define('DB_HOST', 'localhost');
define('DB_USERNAME', [
    /* Localhost */
    __LOCALHOST__ => 'root', 

    /* partsv2.abs.company */ 
    // u356746783_parts_v2
    __PARTS_V2__ => 'absccgra_root',

    /* washv2.abs.company */
    // u356746783_washv2_abs
    __WASH_V2__ => 'absccgra_root',

    /* tenleasing.absyeg.store */
    // u356746783_tenleasing
    __TEN_LEASING__ => 'absccgra_root',

    /* vanguard.absyeg.store */
    // u356746783_vanguard
    __VANGUARD__ => 'absccgra_root',

    /* salvageparts.absyeg.store */
    // u356746783_salvage_parts
    __SALVAGE_PARTS__ => 'absccgra_root',
    ][$offset]
);

define('DB_PASSWORD', [
    /* Localhost */
    __LOCALHOST__ => '',

    /* partsv2.abs.company */ 
    // Fr:W="|ryHn/AQ.%2.pznd`N*#([97/Q
    __PARTS_V2__ => 'S$B#GjeF4QYMeO2xuCKvZav4#E4RVBPpr#xBDw3VGJC%tAI!qIvLG4ai@i05%B6Wou1&O%KJp2#&Qf*s',

    /* washv2.abs.company */
    // R~%CWR3+p],N_sSN_@D"YPKSo-}"ay,=
    __WASH_V2__ => 'S$B#GjeF4QYMeO2xuCKvZav4#E4RVBPpr#xBDw3VGJC%tAI!qIvLG4ai@i05%B6Wou1&O%KJp2#&Qf*s',

    /* tenleasing.absyeg.store */
    // [hP>dQ/?4zXp:w"^P*^J9g;``EC&`o3V
    __TEN_LEASING__ => 'S$B#GjeF4QYMeO2xuCKvZav4#E4RVBPpr#xBDw3VGJC%tAI!qIvLG4ai@i05%B6Wou1&O%KJp2#&Qf*s',

    /* vanguard.absyeg.store */
    // 9j9Sr`q"!z{9tN<2{~q\"XJ!,h=?)4M]
    __VANGUARD__ => 'S$B#GjeF4QYMeO2xuCKvZav4#E4RVBPpr#xBDw3VGJC%tAI!qIvLG4ai@i05%B6Wou1&O%KJp2#&Qf*s',

    /* salvageparts.absyeg.store */
    // Z`(*")M/]?2+#zJ@Du,gr[;}>_v/<wc;
    __SALVAGE_PARTS__ => 'S$B#GjeF4QYMeO2xuCKvZav4#E4RVBPpr#xBDw3VGJC%tAI!qIvLG4ai@i05%B6Wou1&O%KJp2#&Qf*s',
    ][$offset]
);

define('DB_NAME', [
    /* Localhost */ 
    __LOCALHOST__ => 'abs', 

    /* partsv2.abs.company */ 
    // u356746783_parts_v2
    __PARTS_V2__ => 'absccgra_parts',

    /* washv2.abs.company */
    // u356746783_washv2_abs
    __WASH_V2__ => 'absccgra_wash',

    /* tenleasing.absyeg.store */
    // u356746783_tenleasing
    __TEN_LEASING__ => 'u356746783_tenleasing',

    /* vanguard.absyeg.store */
    // u356746783_vanguard
    __VANGUARD__ => 'u356746783_vanguard',

    /* salvageparts.absyeg.store */
    // u356746783_salvage_parts
    __SALVAGE_PARTS__ => 'u356746783_salvage_parts',
    ][$offset]
);
?>