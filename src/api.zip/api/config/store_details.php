<?php

// Federal Tax Rate
define('FEDERAL_TAX_RATE',  5.00);

/**
 * Store Details
 */
class StoreDetails {

    // Store Identifies
    public const ALL_STORES = 1;
    public const EDMONTON = 2;
    public const CALGARY = 3;
    public const NISKU = 4;
    public const VANCOUVER = 5;
    public const SLAVE_LAKE = 6;
    public const DELTA = 7;
    public const REGINA = 8;
    public const SASKATOON = 9;

    // Business Name
    public const BUSINESS_NAME = [WASH => 'ABS TRUCK WASH AND LUBE LTD.', PARTS =>'ABS TRUCK & TRAILERS PARTS LTD.'][SYSTEM_INIT_MODE];

    // Salvage Parts Store Details
    public const SALVAGE_PARTS_STORE_DETAILS = [
        self::ALL_STORES => null,
         self::EDMONTON => [
            'id' => self::EDMONTON, 
            'name' => 'Edmonton',
            'location_code' => 'E',
            'timezone' => 'America/Edmonton',
            'pst_tax_rate' => 0.00,
            'hst_tax_rate' => 0.00,
            'gst_hst_tax_rate' => FEDERAL_TAX_RATE,
            'use_hst' => false,
            'business_number' => [
                PARTS => '756104956RP0001', 
                WASH => '',
            ],
            'pst_number' => [
                PARTS => null,
                WASH => null,
            ],
            'address' => [
                'name' => 'ABS SALVAGE USED PARTS LTD.',
                'street1' => '12555 62 ST NW',
                'city' => 'EDMONTON',
                'province' => 'ALBERTA',
                'postal_code' => 'T5W 4W9',
                'country' => 'CANADA',
                'tel' => '+1 (825) 203-1938',
                'fax' => '',
            ],
            'email' => [
                'from_name' => [
                    PARTS => 'No reply from ABS Salvage Used Parts Ltd.',
                    WASH => '',
                ],
                'bcc' => [
                    PARTS => 'abssalvageparts@gmail.com', 
                    WASH => '',
                ],
            ],
            'payment_details' => [
                'email_id' => 'abssalvageparts@gmail.com',
                'checks' => [
                    'payable_to' => 'ABS SALVAGE USED PARTS LTD.',
                    'address' => '12555 62 ST NW, EDMONTON, ALBERTA, T5W 4W9',
                ]
            ],
            'cipher_key' => 'uk.s+vD?acf:Y"-Q:5$.!WQt{)vr(/op',
        ],
    ];

    // Stores
    public const STORE_DETAILS = [
        self::ALL_STORES => null,
        self::EDMONTON => [
            'id' => self::EDMONTON, 
            'name' => 'Edmonton',
            'location_code' => 'E',
            'timezone' => 'America/Edmonton',
            'pst_tax_rate' => 0.00,
            'hst_tax_rate' => 0.00,
            'gst_hst_tax_rate' => FEDERAL_TAX_RATE,
            'use_hst' => false,
            'business_number' => [
                PARTS => '727752099RT0001', 
                WASH => '845421445RT0001',
            ],
            'pst_number' => [
                PARTS => null,
                WASH => null,
            ],
            'address' => [
                'name' => self::BUSINESS_NAME,
                'street1' => '6030 125 AVENUE NW',
                'city' => 'EDMONTON',
                'province' => 'ALBERTA',
                'postal_code' => 'T5W 1Z6',
                'country' => 'CANADA',
                'tel' => '+1 (780) 479-4700',
                'fax' => '+1 (780) 479-7995',
            ],
            'email' => [
                'from_name' => [
                    WASH => 'No reply from ABS Truck Wash and Lube Ltd.', 
                    PARTS => 'No reply from ABS Truck & Trailer Parts Ltd.'
                ],
                'bcc' => [
                    PARTS => 'abstruckparts@gmail.com', 
                    WASH => '',
                ],
            ],
            'payment_details' => [
                'email_id' => 'ABSTRUCKPARTS@GMAIL.COM',
                'checks' => [
                    'payable_to' => self::BUSINESS_NAME,
                    'address' => '6030 125 AVE NW, EDMONTON, ALBERTA, T5W 1Z6',
                ]
            ],
            'cipher_key' => ';5_N$4{]7(nsk>^H4oU~zJ+&?bNC5nK(',
            'disable_over_credit' => False,
        ],
        self::CALGARY => [
            'id' => self::CALGARY, 
            'name' => 'Calgary',
            'location_code' => 'C',
            'timezone' => 'America/Edmonton',
            'pst_tax_rate' => 0.00,
            'hst_tax_rate' => 0.00,
            'gst_hst_tax_rate' => FEDERAL_TAX_RATE,
            'use_hst' => false,
            'business_number' => [
                PARTS => '727752099RT0002', 
                WASH => null,
            ],
            'pst_number' => [
                PARTS => null,
                WASH => null,
            ],
            'address' => [
                'name' => self::BUSINESS_NAME,
                'street1' => '5150 76 AVE SE',
                'city' => 'CALGARY',
                'province' => 'ALBERTA',
                'postal_code' => 'T2C 2X2',
                'country' => 'CANADA',
                'tel' => '+1 (403) 300-6600',
                'fax' => ''
            ],
            'email' => [
                'from_name' => [
                    WASH => 'No reply from ABS Truck Wash and Lube Ltd.', 
                    PARTS => 'No reply from ABS Truck & Trailer Parts Ltd.'
                ],
                'bcc' => [
                    PARTS => 'absparts.calgary@gmail.com', 
                    WASH => '',
                ],
            ],
            'payment_details' => [
                'email_id' => 'ABSTRUCKPARTS@GMAIL.COM',
                'checks' => [
                    'payable_to' => self::BUSINESS_NAME,
                    'address' => '6030 125 AVE NW, EDMONTON, ALBERTA, T5W 1Z6',
                ]
            ],
            'cipher_key' => '#.0l>HH(HhxEP|pZ=gJN/d+f6V<zVnk{',
            'disable_over_credit' => True,
        ],
        self::NISKU => [
            'id' => self::NISKU, 
            'name' => 'Nisku',
            'location_code' => 'N',
            'timezone' => 'America/Edmonton',
            'pst_tax_rate' => 0.00,
            'hst_tax_rate' => 0.00,
            'gst_hst_tax_rate' => FEDERAL_TAX_RATE,
            'use_hst' => false,
            'business_number' => [
                PARTS => '727752099RT0003', 
                WASH => '845421445RT0002',
            ],
            'pst_number' => [
                PARTS => null,
                WASH => null,
            ],
            'address' => [
                'name' => self::BUSINESS_NAME,
                'street1' => '2010 SPARROW DRIVE',
                'city' => 'NISKU',
                'province' => 'ALBERTA',
                'postal_code' => 'T9E 8A2',
                'country' => 'CANADA',
                'tel' => '+1 (780) 334-1900',
                'fax' => ''
            ],
            'email' => [
                'from_name' => [
                    WASH => 'No reply from ABS Truck Wash and Lube Ltd.', 
                    PARTS => 'No reply from ABS Truck & Trailer Parts Ltd.'
                ],
                'bcc' => [
                    PARTS => 'abstruckparts_nisku@outlook.com', 
                    WASH => 'abstruckwash_nisku@outlook.com',
                ],
            ],
            'payment_details' => [
                'email_id' => 'ABSTRUCKPARTS@GMAIL.COM',
                'checks' => [
                    'payable_to' => self::BUSINESS_NAME,
                    'address' => '6030 125 AVE NW, EDMONTON, ALBERTA, T5W 1Z6',
                ]
            ],
            'cipher_key' => 'T+=Xk;T6}!{jCK[h*p/>ty#?4ml_T)A9',
            'disable_over_credit' => False,
        ],
        self::VANCOUVER => [
            'id' => self::VANCOUVER, 
            'name' => 'Vancouver',
            'location_code' => 'V',
            'timezone' => 'America/Vancouver',
            'pst_tax_rate' => 7.00,
            'hst_tax_rate' => 0.00,
            'gst_hst_tax_rate' => FEDERAL_TAX_RATE,
            'use_hst' => false,
            'business_number' => [
                PARTS => '727752099RT0004', 
                WASH => null,
            ],
            'pst_number' => [
                PARTS => 'PST-1480-1016',
                WASH => null,
            ],
            'address' => [
                'name' => 'TRACTION HEAVY DUTY PARTS',
                'street1' => '7351 PROGRESS PLACE',
                'city' => 'DELTA',
                'province' => 'BRITISH COLUMBIA',
                'postal_code' => 'V4G 1A1',
                'country' => 'CANADA',
                'tel' => '+1 (604)-952-0001',
                'fax' => ''
            ],
            'email' => [
                'from_name' => [
                    WASH => 'No reply from ABS Truck Wash and Lube Ltd.', 
                    PARTS => 'No reply from ABS Truck & Trailer Parts Ltd.'
                ],
                'bcc' => [
                    PARTS => 'absparts.traction.delta@gmail.com', 
                    WASH => '',
                ],
            ],
            'payment_details' => [
                'email_id' => 'ABSPARTS.TRACTION.DELTA@GMAIL.COM',
                'checks' => [
                    'payable_to' => 'TRACTION HEAVY DUTY PARTS',
                    'address' => '7351 PROGRESS PLACE, DELTA, BRITISH COLUMBIA, V4G 1A1',
                ],
            ],
            'cipher_key' => 'JL`=rtluOqF|bkVF/g=YOm#>,fk9q1>%',
            'disable_over_credit' => False,
        ],
        self::SLAVE_LAKE => [
            'id' => self::SLAVE_LAKE, 
            'name' => 'Slave Lake',
            'location_code' => 'SL',
            'timezone' => 'America/Edmonton',
            'pst_tax_rate' => 0.00,
            'hst_tax_rate' => 0.00,
            'gst_hst_tax_rate' => FEDERAL_TAX_RATE,
            'use_hst' => false,
            'business_number' => [
                PARTS => '727752099RT0005', 
                WASH => null,
            ],
            'pst_number' => [
                PARTS => null,
                WASH => null,
            ],
            'address' => [
                'name' => self::BUSINESS_NAME,
                'street1' => '#2 301 CARIBOU TRAIL NW',
                'city' => 'SLAVE LAKE',
                'province' => 'ALBERTA',
                'postal_code' => 'T0G 2A0',
                'country' => 'CANADA',
                'tel' => '+1 (780)-849-1912',
                'fax' => ''
            ],
            'email' => [
                'from_name' => [
                    WASH => 'No reply from ABS Truck Wash and Lube Ltd.', 
                    PARTS => 'No reply from ABS Truck & Trailer Parts Ltd.'
                ],
                'bcc' => [
                    PARTS => 'abstruckparts.slavelake@gmail.com', 
                    WASH => '',
                ],
            ],
            'payment_details' => [
                'email_id' => 'ABSTRUCKPARTS@GMAIL.COM',
                'checks' => [
                    'payable_to' => self::BUSINESS_NAME,
                    'address' => 'PO BOX 55, SLAVE LAKE, ALBERTA, T0G 2A0',
                ]
            ],
            'cipher_key' => '+dH<do)&v9z#";BY-%y_L+Ocob4o@-,8',
            'disable_over_credit' => False,
        ],
        self::DELTA => [
            'id' => self::DELTA, 
            'name' => 'Delta',
            'location_code' => 'D',
            'timezone' => 'America/Vancouver',
            'pst_tax_rate' => 7.00,
            'hst_tax_rate' => 0.00,
            'gst_hst_tax_rate' => FEDERAL_TAX_RATE,
            'use_hst' => false,
            'business_number' => [
                PARTS => '707291019RT0001', 
                WASH => null,
            ],
            'pst_number' => [
                PARTS => 'PST-1481-0085',
                WASH => null,
            ],
            'address' => [
                'name' => 'ABS TRUCK AND TRAILER PARTS BC LTD.',
                'street1' => '8380 RIVER RD',
                'city' => 'DELTA',
                'province' => 'BRITISH COLUMBIA',
                'postal_code' => 'V4G 1B5',
                'country' => 'CANADA',
                'tel' => '+1 (604)-952-0001',
                'fax' => ''
            ],
            'email' => [
                'from_name' => [
                    WASH => 'No reply from ABS Truck Wash and Lube Ltd.', 
                    PARTS => 'No reply from ABS Truck & Trailer Parts Ltd.'
                ],
                'bcc' => [
                    PARTS => 'absparts.traction.delta@gmail.com', 
                    WASH => '',
                ],
            ],
            'payment_details' => [
                'email_id' => 'ABSPARTS.TRACTION.DELTA@GMAIL.COM',
                'checks' => [
                    'payable_to' => 'ABS TRUCK AND TRAILER PARTS BC LTD.',
                    'address' => '8380 RIVER RD, DELTA, BRITISH COLUMBIA, V4G 1B5',
                ],
            ],
            'cipher_key' => 'K(|;Q7cKYnb~ZMa/6^67pb{}(bWm2/s5',
            'disable_over_credit' => False,
        ],

        // https://www.zeitverschiebung.net/en/timezone/america--regina
        self::REGINA => [
            'id' => self::REGINA, 
            'name' => 'Regina',
            'location_code' => 'R',
            'timezone' => 'America/Regina',
            'pst_tax_rate' => 6.00,
            'hst_tax_rate' => 0.00,
            'gst_hst_tax_rate' => FEDERAL_TAX_RATE,
            'use_hst' => false,
            'business_number' => [
                PARTS => '700635212RC0001',
                WASH => null,
            ],
            'pst_number' => [
                PARTS => '8040305',
                WASH => null,
            ],
            'address' => [
                'name' => 'ABS TRUCK AND TRAILER PARTS SK LTD.',
                'street1' => '1600 ROSS AVE EAST',
                'city' => 'REGINA',
                'province' => 'SASKATCHEWAN',
                'postal_code' => 'S4N 7A3',
                'country' => 'CANADA',
                'tel' => '+1 (306) 545-6600',
                'fax' => ''
            ],
            'email' => [
                'from_name' => [
                    WASH => 'No reply from ABS Truck Wash and Lube SK Ltd.', 
                    PARTS => 'No reply from ABS Truck & Trailer Parts SK Ltd.'
                ],
                'bcc' => [
                    PARTS => 'abstruckparts.regina@gmail.com', 
                    WASH => '',
                ],
            ],
            'payment_details' => [
                'email_id' => 'abstruckparts.regina@gmail.com',
                'checks' => [
                    'payable_to' => '',
                    'address' => '',
                ],
            ],
            'cipher_key' => 'Ewk"tuZ2<$tqwnF2tc3X%5r(d?/:|9JU',
            'disable_over_credit' => False,
        ],

        self::SASKATOON => [
            'id' => self::SASKATOON, 
            'name' => 'Saskatoon',
            'location_code' => 'S',
            'timezone' => 'America/Regina',
            'pst_tax_rate' => 6.00,
            'hst_tax_rate' => 0.00,
            'gst_hst_tax_rate' => FEDERAL_TAX_RATE,
            'use_hst' => false,
            'business_number' => [
                PARTS => '700635212RC0001',
                WASH => null,
            ],
            'pst_number' => [
                PARTS => '8040305',
                WASH => null,
            ],
            'address' => [
                'name' => 'ABS TRUCK AND TRAILER PARTS SK LTD.',
                'street1' => '30-3710 MILLAR AVE',
                'city' => 'SASKATOON',
                'province' => 'SASKATCHEWAN',
                'postal_code' => 'S7P 0B1',
                'country' => 'CANADA',
                'tel' => '+1 (306) 668-8881',
                'fax' => ''
            ],
            'email' => [
                'from_name' => [
                    WASH => '', 
                    PARTS => 'No reply from ABS Truck & Trailer Parts SK Ltd.'
                ],
                'bcc' => [
                    PARTS => 'abstruckparts.sask@gmail.com', 
                    WASH => '',
                ],
            ],
            'payment_details' => [
                'email_id' => 'abstruckparts.sask@gmail.com',
                'checks' => [
                    'payable_to' => '',
                    'address' => '',
                ],
            ],
            'cipher_key' => '=yyS]q=)NYpy+{p$i[;gT`/|7Uho^x`9',
            'disable_over_credit' => False,
        ],
    ];
}
?>